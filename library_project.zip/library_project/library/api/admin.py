from django.contrib import admin
from .models import Book, Student

admin.site.register(Book)
# Register your models here.
